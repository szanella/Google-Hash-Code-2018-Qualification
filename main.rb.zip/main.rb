require 'pry'

file = ARGV[0]

file_lines = File.read("./#{file}.in").split("\n")

rows, columns, fleet, rides, bonus, steps = file_lines[0].split(' ').map {|x| x.to_i}

rides_data = []

def distance r1, c1, r2, c2
  (r2 - r1).abs + (c2 - c1).abs
end

def score_ride car_pos, ride, bonus, step
  ride[:length] +
      (distance(car_pos[0], car_pos[1], ride[:r1], ride[:c1]) <= (ride[:start] - step) ? bonus : 0)
end

file_lines[1..-1].each_with_index do |line, index|
  params = line.split ' '
  rides_data.push({
      r1: params[0].to_i,
      c1: params[1].to_i,
      r2: params[2].to_i,
      c2: params[3].to_i,
      start: params[4].to_i,
      finish: params[5].to_i,
      index: index,
      length: distance(params[0].to_i, params[1].to_i, params[2].to_i, params[3].to_i)
  })
end

rides_data = rides_data.sort_by { |ride| ride[:finish] }.reverse

# puts rows
# puts columns
# puts fleet
# puts rides
# puts bonus
# puts steps
# puts rides_data

vehicles_free_step = Array.new(fleet, 0)

vehicles_positions = Array.new(fleet)
vehicles_positions.each_index do |i|
  vehicles_positions[i] = [0, 0]
end

vehicles_rides = Array.new(fleet)
vehicles_rides.each_index do |i|
  vehicles_rides[i] = []
end

# rides_data.each do |ride|
#   puts score_ride [0, 0], ride, bonus, 0
# end

car_to_ride_distances = []

car_to_ride_scores = []

steps.times do |step|
  rides_data.each_with_index do |ride, r_index|
    if ride[:finish] < step
      rides_data.delete_at r_index
    else
      break
    end
  end
  puts "Step: #{step}/#{steps}. Remaining rides: #{rides_data.length}"

  no_ride_assigned = true
  all_vehicles_free = true
  break if rides_data.empty?
  recomputed_distances = 0
  computed_scores = 0
  loops = 0

  vehicles_free_step.each_with_index do |free_step, car_index|
    if free_step > step
      all_vehicles_free = false
      next
    end

    best_score = 0
    chosen_ride_index = nil
    distance_from_chosen_ride = nil

    rides_data.each_with_index do |ride, ride_index|
      loops += 1

      unless car_to_ride_distances[car_index] && car_to_ride_distances[car_index][ride[:index]]
        recomputed_distances += 1 if step > 41450
        car_to_ride_distances[car_index] = [] if car_to_ride_distances[car_index].nil?
        car_to_ride_distances[car_index][ride[:index]] = distance(vehicles_positions[car_index][0], vehicles_positions[car_index][1], ride[:r1], ride[:c1])
      end
      next if (step + car_to_ride_distances[car_index][ride[:index]] + ride[:length]) >= ride[:finish] || (distance_from_chosen_ride && (distance_from_chosen_ride < car_to_ride_distances[car_index][ride[:index]]))

      score= score_ride(vehicles_positions[car_index], ride, bonus, step)
      computed_scores += 1 if step > 41450
      if score >= best_score
        best_score = score
        chosen_ride_index = ride_index
        distance_from_chosen_ride = car_to_ride_distances[car_index][ride[:index]]
      end
    end


    if chosen_ride_index
      no_ride_assigned = false
      chosen_ride = rides_data[chosen_ride_index]
      vehicles_rides[car_index].push chosen_ride[:index]
      vehicles_free_step[car_index] = step + distance_from_chosen_ride + chosen_ride[:length]
      vehicles_positions[car_index] = [chosen_ride[:r2], chosen_ride[:c2]]
      car_to_ride_distances[car_index] = []
      car_to_ride_scores[car_index] = []
      rides_data.delete_at chosen_ride_index
    end
  end

  break if all_vehicles_free && no_ride_assigned
  # puts "Loops #{loops}"
  # puts "Distances #{recomputed_distances}" if step > 41450
  # puts "Scores #{computed_scores}" if step > 41450
end

submission = vehicles_rides.map do |veh_rid|
  "#{veh_rid.length} #{veh_rid.join(' ')}"
end.join("\n")

File.write("./#{file}.out", submission)